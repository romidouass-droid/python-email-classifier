# Task 2 - Email Text Extraction Module

## What this does
`extract_email_text(file_path)` reads a raw .eml file and returns a single
cleaned text string containing the subject, sender, and plain-text body —
ready to feed into Ahlam's AI classification step.

- Skips attachments (PDFs, images, docs)
- Converts HTML body to plain text
- Removes extra spaces, blank lines, and garbage symbols

## How to run it

1. Open this folder in VS Code (or any terminal).
2. Install the one dependency:
   ```
   pip install -r requirements.txt
   ```
3. Run it against the sample emails:
   ```
   python extract_email_text.py sample_emails/*.eml
   ```
   (On Windows, if the wildcard doesn't expand, list files individually,
   e.g. `python extract_email_text.py sample_emails\01_plain_text.eml`)

## Using it in code (for Ahlam / integration)

```python
from extract_email_text import extract_email_text

clean_text = extract_email_text("some_email.eml")
print(clean_text)
```

## Files included
- `extract_email_text.py` - the function + command-line test runner
- `requirements.txt` - dependencies (beautifulsoup4)
- `sample_emails/` - 5 test .eml files (plain text, HTML, attachment, spam/garbage symbols, short notification)
